$(function(){    
    $('#brgy-report').on('click',function(){      
        // if(unit_permission('provincial', var_session)){
            $(document).on('change', '#lgu', function(){        
                $(document).gmLoadPage({
                    url: baseUrl + 'reports/brgy',
                    data: {brgy_id: $('#lgu option:selected').val()},
                    load_on: '#brgy-reports'
                });            
            })
        // }else{
            $(document).gmLoadPage({
                url: baseUrl + 'reports/brgy',
                data: {brgy_id: $('#lgu option:selected').val()},
                load_on: '#brgy-reports'
            });
        // }  
        $('#modal-barangay-report').modal('show');
    })

    $('#print').on('click',function(){
        
        $('#printable').printThis({
            header: $('#brgy-r-header').html(),
        });
    })
}) 