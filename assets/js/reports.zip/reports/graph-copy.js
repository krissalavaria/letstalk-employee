           
            // var itr = moment.twix(new Date(start),new Date(end)).iterate("days");
            // var formatted_date = [];
            // formatted_date.push('date');
            // var dates = [];
            // var range=[];
            // while(itr.hasNext()){
            //     // range.push(itr.next().format("YYYY-MM-DD"))
            //     dates.push(itr.next().format("YYYY-MM-DD"));
            //     formatted_date.push(itr.next().format("MM/DD/YYYY"));
            // }
            // console.log(range);
           function load(data){
               
                
                var colors = ['#1b5e20', '#0097a7', '#d32f2f'];
                var dom = document.getElementById("container");
                var myChart = echarts.init(dom);
                var app = {};
                option = null;
                var formatted_date = [];                 
                var dates = [];
                
                formatted_date.push('date');
                data = data.data;
                $.each(data,function(key,value){
                    $.each(value,function(key1,status){
                        if(!dates.includes(status.date)){
                            formatted_date.push( (new Date(status.date)).toLocaleDateString("en-US") );
                            dates.push(status.date);
                        }
                    })
                })   
                
                dates.sort(function(a,b){
                    
                    return new Date(a) - new Date(b);
                });
                
                formatted_date.sort(function(a,b){
                    
                    return new Date(a) - new Date(b);
                });
                
                var merge = [];
                merge.push(formatted_date);
                
                $.each(data,function(key,value){

                    var formatted_data = [];
                    formatted_data.push(key);
                    $.each(dates,function(kdate, date){
                        let obj = value.find(obj => obj.date === date);
                        formatted_data.push( obj ? parseInt(obj.count) : 0 );
                    });
                    merge.push(formatted_data);
                });
                
                option = {
                    title: {
                        left: 'left',
                        text: 'Daily Status Report',
                       
                    },
                    color: colors,
                    legend: {},
                    tooltip: {
                        trigger: 'axis',
                        axisPointer: {
                            type: 'cross'
                        }
                    },
                    dataset: {
                        source: merge
                    },
                    xAxis: {type: 'category'},
                    yAxis: {gridIndex: 0},
                    dataZoom: [
                        { 
                            type: 'inside', 
                            start: 0,      
                            end: 100
                        },
                        {
                            start: 0,
                            end: 10,
                            handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                            handleSize: '80%',
                            handleStyle: {
                                color: '#fff',
                                shadowBlur: 3,
                                shadowColor: 'rgba(0, 0, 0, 0.6)',
                                shadowOffsetX: 2,
                                shadowOffsetY: 2
                            }
                        }
                            ],
                            grid: {top: '55%'},
                            series: [
                                {type: 'line', smooth: true, seriesLayoutBy: 'row'},
                                {type: 'line', smooth: true, seriesLayoutBy: 'row'},
                                {type: 'line', smooth: true, seriesLayoutBy: 'row'},
                            
                                {
                                    type: 'pie',
                                    id: 'pie',
                                    radius: '30%',
                                    center: ['50%', '25%'],
                                    label: {
                                        formatter: '{b}: {@'+ formatted_date[formatted_date.length-1]+'}  ({d}%)'
                                    },
                                    encode: {
                                        itemName: 'date',
                                        value: formatted_date[formatted_date.length-1],
                                        tooltip: formatted_date[formatted_date.length-1]
                                    }
                                }
                            ]
                };

                        myChart.on('updateAxisPointer', function (event) {
                            var xAxisInfo = event.axesInfo[0];
                            if (xAxisInfo) {
                                var dimension = xAxisInfo.value + 1;
                                myChart.setOption({
                                    series: {
                                        id: 'pie',
                                        label: {
                                            formatter: '{b}: {@[' + dimension + ']} ({d}%)'
                                        },
                                        encode: {
                                            value: dimension,
                                            tooltip: dimension
                                        }
                                    }
                                });
                            }
                        });

                        myChart.setOption(option);

            }
            
            function load_outcome(data){
                var colors = ['#0097a7', '#d32f2f'];
                var dom = document.getElementById("container1");
                var myChart = echarts.init(dom);
                var app = {};
                option = null;
                                
                var dates = [];
                var formatted_date = [];
                data = data.data;
                $.each(data,function(key,value){
                    $.each(value,function(key1,status){
                        if(!dates.includes(status.date)){
                            formatted_date.push( (new Date(status.date)).toLocaleDateString("en-US") );
                            dates.push(status.date);
                        }
                    })
                })   
                dates.sort(function(a,b){
                    
                    return new Date(a) - new Date(b);
                });
                formatted_date.sort(function(a,b){
                    
                    return new Date(a) - new Date(b);
                });
                var merge = [];
                merge.push(formatted_date);
                
                $.each(data,function(key,value){

                    var formatted_data = [];
                    $.each(dates,function(kdate, date){
                        let obj = value.find(obj => obj.date === date);
                        formatted_data.push( obj ? parseInt(obj.count) : 0 );
                    });
                    merge.push(formatted_data);
                });
                option = {
                        color: colors,

                        tooltip: {
                            trigger: 'none',
                            axisPointer: {
                                type: 'cross'
                            }
                        },
                        legend: {
                            data:['RECOVERED', 'DIED']
                        },
                        grid: {
                            top: 70,
                            bottom: 50
                        },
                        xAxis: [
                            {
                                type: 'category',
                                axisTick: {
                                    alignWithLabel: true
                                },
                                axisLine: {
                                    onZero: false,
                                    lineStyle: {
                                        color: colors[1]
                                    }
                                },
                                axisPointer: {
                                    label: {
                                        formatter: function (params) {
                                            return params.value
                                                + (params.seriesData.length ? '：' + params.seriesData[0].data : '');
                                        }
                                    }
                                },
                                data: merge[0]
                            },
                            {
                                type: 'category',
                                axisTick: {
                                    alignWithLabel: true
                                },
                                axisLine: {
                                    onZero: false,
                                    lineStyle: {
                                        color: colors[0]
                                    }
                                },
                                axisPointer: {
                                    label: {
                                        formatter: function (params) {
                                            return params.value
                                                + (params.seriesData.length ? '：' + params.seriesData[0].data : '');
                                        }
                                    }
                                },
                                data: merge[0]
                            }
                        ],
                        yAxis: [
                            {
                                type: 'value'
                            }
                        ],
                        dataZoom: [
                            { 
                                type: 'inside', 
                                start: 0,      
                                end: 100
                            },
                            {
                                start: 0,
                                end: 100,
                                handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                                handleSize: '80%',
                                handleStyle: {
                                    color: '#fff',
                                    shadowBlur: 3,
                                    shadowColor: 'rgba(0, 0, 0, 0.6)',
                                    shadowOffsetX: 2,
                                    shadowOffsetY: 2
                                }
                            }
                        ],
                        series: [
                            {
                                name: 'RECOVERED',
                                type: 'line',
                                xAxisIndex: 1,
                                smooth: true,
                                data: merge[1]
                            },
                            {
                                name: 'DIED',
                                type: 'line',
                                smooth: true,
                                data: merge[2]
                            }
                        ]
                    };
                    ;
                    
                    myChart.setOption(option);

            }
    $(document).gmPostHandler({
        url: 'reports/services/reports_service/status_report',
        function_call: true,
        function: load,
        parameter: true,
    });

    $(document).gmPostHandler({
        url: 'reports/services/reports_service/outcome_report',
        function_call: true,
        function: load_outcome,
        parameter: true,
    });