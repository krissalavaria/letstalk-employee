var Listype_of_report = null;
$(document).on('click', '.view-list-report', function (){  
    var value = $(this).data('val');
    $('#list-of-remarks').html('');     
    Listype_of_report = value;
    $('#download-report-in-model').val($(this).data('val'));
    $('#modal-list-remark').modal('show');
});

/** generate list of LSI */
$(document).on('click', '#view-lists', function(){
    if(valSession.city_id == '0'){        
        $(document).gmLoadPage({
            url: baseUrl + 'reports/get_all_remarks_list',
            data: {
                value: Listype_of_report,    
                cityID: $('#select-city option:selected').val()        
            },
            function_call: true,                        
            beforesend: true,
            beforesend_function: [
                {
                    function: loading,
                    load_on: '#loading-remarks'
                }
            ],
            load_on: '#list-of-remarks',
            disable_elem: [ '#view-lists' ]
        });            
    }else{
        $(document).gmLoadPage({
            url: baseUrl + 'reports/get_all_remarks_list',
            data: {
                value: Listype_of_report,    
                cityID: $('#select-city option:selected').val()        
            },
            load_on: '#list-of-remarks'
        });
    }                      
});        

var statRemarks = null;
$(document).on('click', '.view-list-statRemarks', function (){  
    var values = $(this).data('val');
    $('#list-of-statRemarks').html('');     
    statRemarks = values;
    $('#download-report-in-model').val($(this).data('val'));
    $('#modal-list-statRemarks').modal('show');
});

$(document).on('click', '#view-lists-statRemarks', function(){
    if(valSession.city_id == '0'){                
        $(document).gmLoadPage({
            url: baseUrl + 'reports/get_list_status',
            data: {
                value: statRemarks,    
                cityID: $('#select-city-stat option:selected').val()        
            },
            load_on: '#list-of-statRemarks'
        });            
    }else{
        $(document).gmLoadPage({
            url: baseUrl + 'reports/get_list_status',
            data: {
                value: statRemarks      
            },
            load_on: '#list-of-statRemarks'
        });
    } 
});           

/** get all list of person outcomes */
var oucomeValue = null;
$(document).on('click', '.oc-clicked', function (){  
    var outcomeVal = $(this).data('val');
    $('#list-of-outcome').html('');     
    oucomeValue = outcomeVal;
    $('#download-report-in-model').val($(this).data('val'));
    $('#modal-list-outcome').modal('show');
});

$(document).on('click', '#view-lists-outcome', function(){
    if(valSession.city_id == '0'){           
        $(document).gmLoadPage({
            url: baseUrl + 'reports/get_list_otucome_status',
            data: {
                value: oucomeValue,    
                cityID: $('#select-city-outcome option:selected').val()        
            },
            load_on: '#list-of-outcome'
        })        
    }else{
        $(document).gmLoadPage({
            url: baseUrl + 'reports/get_list_otucome_status',
            data: {
                value: oucomeValue  
            },
            load_on: '#list-of-outcome'
        });
    }          
});   

/** view all list of confirmed cases */
$(document).on('click', '#st-clicked', function(){     
    var valueST = $(this).data('val');
    $('#list-of-confirmed').html('');
    $(document).on('click', '#view-lists-confirmed', function(){
        if(valSession.city_id == '0'){             
            $(document).gmLoadPage({
                url: baseUrl + 'reports/get_list_person_status',
                data: {
                    value: valueST,    
                    cityID: $('#select-city-confirmed option:selected').val()        
                },
                load_on: '#list-of-confirmed',                
            });                        
        }else{
            $(document).gmLoadPage({
                url: baseUrl + 'reports/get_list_person_status',
                data: {
                    value: valueST    
                },
                load_on: '#list-of-confirmed'
            });
        }
    });                
    $('#download-report-in-model').val($(this).data('val'));
    $('#modal-list-confirmed').modal('show');       
});
