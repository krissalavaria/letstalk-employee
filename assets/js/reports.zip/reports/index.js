// const { data } = require("jquery");

/** generate reports per selection */
$(document).on('click', '#generate-report', function () {
    $(document).gmLoadPage({
        url: baseUrl + 'reports/load_generated_activities',
        data: {
            actID: $('.form-control[data-field="activities"]').val(),
            type: $('#activities option:selected').data('type')
        },
        load_on: '#load-generated'
    });
});

function download(data) {
    var $a = $("<a>");
    $a.attr("href", data.file);
    $("body").append($a);
    $a.attr("download", data.file_name);
    $a[0].click();
    $a.remove();
}


$(document).on('click', '#download-report', function () {

    $(document).gmPostHandler({
        url: 'reports/get_list_downloadable',
        selector: '.barangay-form',
        field: 'field',
        data: {
            actID: $('.form-control[data-field="activities"]').val(),
            type: $('#activities option:selected').data('type')
        },
        function_call: true,
        function: download,
        parameter: true,
        beforesend: true,
        alert_on_error: false,
        add_functions: [{
            function: success,
            parameter: true,
        }],
        beforesend_function: [
            {
                function: loading,
                load_on: '.loading[data-id="downloadable"]'
            }
        ],
        errorsend: true,
        errorsend_function: [
            {
                function: error_connection,
                msg: "Please check your connection and try again."
            }
        ],
        function_call_on_error: true,
        error_function: [
            {
                function: error,
                parameter: true,
            }
        ]
    });

});


function download_modal(data){
    var $a = $("<a>");
    $a.attr("href", data.file);
    $("body").append($a);
    $a.attr("download", data.file_name);
    $a[0].click();
    $a.remove();
}

$(document).on('click', '#download-report-in-model', function () {
    
    $(document).gmPostHandler({
        url: 'reports/get_list_downloadable_modal',
        data: {
            value: $(this).val(),    
            cityID: $('#select-city option:selected').val()      
        },
        function_call: true,
        function: download_modal,
        parameter: true,
        beforesend: true,
        alert_on_error: false,
        add_functions: [{
            function: success,
            parameter: true,
        }],
        beforesend_function: [
            {
                function: loading,
                load_on: '.loading[data-id="downloadable"]'
            }
        ],
        errorsend: true,
        errorsend_function: [
            {
                function: error_connection,
                msg: "Please check your connection and try again."
            }
        ],
        function_call_on_error: true,
        error_function: [
            {
                function: error,
                parameter: true,
            }
        ]
    });

});