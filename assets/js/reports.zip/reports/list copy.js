/** generate list of LSI */
$(document).on('click', '#view-list-lsi', function (){  
    var valued = $(this).data('val');
    $('#list-of-remarks').html('');     
    
    if(valSession.city_id == '0'){
        $(document).on('change', '#select-city', function(){        
            $(document).gmLoadPage({
                url: baseUrl + 'reports/get_all_remarks_list',
                data: {
                    value: valued,    
                    cityID: $('#select-city option:selected').val()        
                },
                load_on: '#list-of-remarks'
            })
        });
    }else{
        $(document).gmLoadPage({
            url: baseUrl + 'reports/get_all_remarks_list',
            data: {
                value: valued,    
                cityID: $('#select-city option:selected').val()        
            },
            load_on: '#list-of-remarks'
        });
    }              
    $('#download-report-in-model').val($(this).data('val'));
    $('#modal-list-remark').modal('show');
});

$(document).on('click', '#view-list-rof', function (){  
    var valued = $(this).data('val');
    $('#list-of-remarks').html('');     
    
    if(valSession.city_id == '0'){
        $(document).on('change', '#select-city', function(){        
            $(document).gmLoadPage({
                url: baseUrl + 'reports/get_all_remarks_list',
                data: {
                    value: valued,    
                    cityID: $('#select-city option:selected').val()        
                },
                load_on: '#list-of-remarks'
            })
        });
    }else{
        $(document).gmLoadPage({
            url: baseUrl + 'reports/get_all_remarks_list',
            data: {
                value: valued,    
                cityID: $('#select-city option:selected').val()        
            },
            load_on: '#list-of-remarks'
        });
    }              
    $('#download-report-in-model').val($(this).data('val'));
    $('#modal-list-remark').modal('show');
});

$(document).on('click', '#view-list-apor', function (){  
    var valued = $(this).data('val');
    $('#list-of-remarks').html('');     
    
    if(valSession.city_id == '0'){
        $(document).on('change', '#select-city', function(){        
            $(document).gmLoadPage({
                url: baseUrl + 'reports/get_all_remarks_list',
                data: {
                    value: valued,    
                    cityID: $('#select-city option:selected').val()        
                },
                load_on: '#list-of-remarks'
            })
        });
    }else{
        $(document).gmLoadPage({
            url: baseUrl + 'reports/get_all_remarks_list',
            data: {
                value: valued,    
                cityID: $('#select-city option:selected').val()        
            },
            load_on: '#list-of-remarks'
        });
    }              
    $('#download-report-in-model').val($(this).data('val'));
    $('#modal-list-remark').modal('show');
});

/** generate lists of home quarantine */
$(document).on('click', '.hq-clicked', function(){
    var valueHQ = $(this).data('val');

    $('#list-of-remarks').html('');
    if(valSession.city_id == '0'){
        $(document).on('change', '#select-city', function(){        
            $(document).gmLoadPage({
                url: baseUrl + 'reports/get_list_status',
                data: {
                    value: valueHQ,    
                    cityID: $('#select-city option:selected').val()        
                },
                load_on: '#list-of-remarks'
            })
        });
    }else{
        $(document).gmLoadPage({
            url: baseUrl + 'reports/get_list_status',
            data: {
                value: valueHQ      
            },
            load_on: '#list-of-remarks'
        });
    }        

    $('#download-report-in-model').val($(this).data('val'));

    $('#modal-list-remark').modal('show');  
});

/** get all list of person outcomes */
$(document).on('click', '.oc-clicked', function(){
    var valueOC = $(this).data('val');

    $('#list-of-remarks').html('');
    if(valSession.city_id == '0'){
        $(document).on('change', '#select-city', function(){        
            $(document).gmLoadPage({
                url: baseUrl + 'reports/get_list_otucome_status',
                data: {
                    value: valueOC,    
                    cityID: $('#select-city option:selected').val()        
                },
                load_on: '#list-of-remarks'
            })
        });
    }else{
        $(document).gmLoadPage({
            url: baseUrl + 'reports/get_list_otucome_status',
            data: {
                value: valueOC  
            },
            load_on: '#list-of-remarks'
        });
    }      

    $('#download-report-in-model').val($(this).data('val'));
    $('#modal-list-remark').modal('show');
});

$(document).on('click', '.st-clicked', function(){
    var valueST = $(this).data('val');

    $('#list-of-remarks').html('');
    if(valSession.city_id == '0'){
        $(document).on('change', '#select-city', function(){        
            $(document).gmLoadPage({
                url: baseUrl + 'reports/get_list_person_status',
                data: {
                    value: valueST,    
                    cityID: $('#select-city option:selected').val()        
                },
                load_on: '#list-of-remarks'
            })
        });
    }else{
        $(document).gmLoadPage({
            url: baseUrl + 'reports/get_list_person_status',
            data: {
                value: valueST    
            },
            load_on: '#list-of-remarks'
        });
    }        

    $('#download-report-in-model').val($(this).data('val'));

    $('#modal-list-remark').modal('show');   
});